
### Display error in calculated electron density
### compared to manufacturers values


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math

data = pd.read_csv("relative-e-dens.csv", sep=";")

### PLOT SUBS ON X, RHOS ON Y ###

x = []
for i in range(0,14):
    
    sub = data.iloc[i,0] # Subs
    x.append(sub)
#------------------
y_calc = []
for i in range(0,14):
    
    rho = float(data.iloc[i,1]) #Calculated RED
    y_calc.append(rho)
#------------------
y_manu = []
for i in range(0,14):
    
    rho = float(data.iloc[i,2]) #Manual RED
    y_manu.append(rho)
#------------------

##plt.plot(x,y_calc, label = "Calculated \u03C1$_{e}$")
##plt.plot(x,y_manu, label = "Theoretical \u03C1$_{e}$")
##plt.xlabel("Substitute")
##plt.xticks(rotation=30)
##plt.ylabel("Relative electron density")
##plt.title("Calculated vs. theoretical \u03C1$_{e}$")
##plt.legend()
##plt.grid(color='gainsboro')
##plt.show()
##
##
##plt.plot(y_manu,y_calc,'o')
##plt.xlabel("Theoretical \u03C1$_{e}$")
##plt.ylabel("Calculated \u03C1$_{e}$")
##plt.title("Calculated vs. theoretical \u03C1$_{e}$ (2)")
##plt.grid(color='gainsboro')
##xlin = np.linspace(0,2.5,100)
##plt.plot(xlin, xlin, "darkgray", label=f"x=y")
##plt.legend()
##plt.show()

######################## Error-barplot ######################
    
xlen = np.arange(len(x))  # the label locations
width = 0.35  # the width of the bars

rel_err = []
for i in range(0,14):
    
    err = float(data.iloc[i,5]) #Relative error (abs. error / calculated rho)
    rel_err.append(err)

fig, ax = plt.subplots()
rects1 = ax.bar(xlen - width/2, rel_err, width, yerr=0, label='Relative error in %')
#rects2 = ax.bar(xlen + width/2, y_manu, width, label='Theoretical')

# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_ylabel('Error')
ax.set_title('Calculated \u03C1$_{e}$ error')
ax.set_xticks(xlen)
ax.set_xticklabels(x)
plt.xticks(rotation=30)
ax.legend()


##def autolabel(rects):
##    """Attach a text label above each bar in *rects*, displaying its height."""
##    for rect in rects:
##        height = rect.get_height()
##        ax.annotate('{}'.format(height),
##                    xy=(rect.get_x() + rect.get_width() / 2, height),
##                    xytext=(0, 5),  # 3 points vertical offset
##                    textcoords="offset points",
##                    ha='center', va='bottom')
##
##
##autolabel(rects1)


fig.tight_layout()

plt.show()
