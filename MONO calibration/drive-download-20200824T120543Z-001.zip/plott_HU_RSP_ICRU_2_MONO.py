### PLOT HU vs RSP (ICRU tissues) ###

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pwlf

data = pd.read_csv("HU_RSP_ICRUt_2.csv", sep=";")

#########################
### IMPORT DATAPOINTS ###
#########################
HU  = []
RSP = []
##print(data.iloc[0,1])     #For double checking koordinates
##print(data.iloc[1,1])

for i in range(0,58):
    HUx  = float(data.iloc[i,0])
    RSPx = float(data.iloc[i,1])
    HU.append(HUx)
    RSP.append(RSPx)

HUa  = np.array([HU])
RSPa = np.array([RSP])

###########################
### MAKE PIECEWICE PLOT ###
###########################

#Line segment locations
x0 = np.array([min(HU),20,400,max(HU)])

my_pwlf = pwlf.PiecewiseLinFit(HU,RSP)
my_pwlf.fit_with_breaks(x0)

xHat = np.linspace(min(HU), max(HU), num=10000)
yHat = my_pwlf.predict(xHat)

plt.figure()
plt.plot(HU, RSP, 'x')
plt.plot(xHat, yHat, '-')
plt.title('HU vs RSP for ICRU tissues')
plt.xlabel('Calculated HU')
plt.ylabel('Calculated RSP')
plt.show()

