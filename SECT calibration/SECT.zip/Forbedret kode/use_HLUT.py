### USE HLUT ON MEASURED HU VALUES ###

import numpy as np
import pandas as pd
data = pd.read_csv("Data/Measured_Mean_HU.csv")

break1 = 20
break2 = 400

def HLUT(HU): # HU -> RSP, functions from "make_HLUT.py"
    if HU < break1:
        RSP = 0.000976117269844176*HU + 1.0161105542626
    elif break1 < HU < break2:
        RSP = 0.00075859236434946*HU + 1.0204610523725
    elif HU > break2:
        RSP = 0.000682367829752312*HU + 1.05095086621136
    return RSP

###Get HU values to be converted to RSP


HU_list = []
for i in range(0,16):
    HU = float(data.iloc[i,0])
    HU_list.append(HU)
print(HU_list)


#Convert to RSP
RSP_list = []
for i in range(0,16):
    HU = float(data.iloc[i,0])
    RSP = HLUT(HU)
    RSP_list.append(RSP)
    print (round((RSP),3))


