### Standard tissues from ICRU Report 44 ###
###          Calculation of HU           ###

import numpy as np
from scipy.optimize import minimize
from scipy.constants import c as c
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math

data = pd.read_csv("Data/standard-tissues.csv")
#########################################################
#### Calculating HU for ICRU tissues

#**# Denominator in A.20 (Goma et al)
wH = 0.112
AH = 1.008
wO = 0.888
AO = 16
k1 = 2.0000*10**(-4)
k2 = 2.0046*10**(-5)

sum_water = wH/AH*(1+k1+k2) + wO/AO*(8+k1*8**2.86+k2*8**4.62)

calc_HU = []

for i in range(2,64):
    sum_row = 0

    for j in range(1,13):
        wi  = float(data.iloc[i,j])/100          
        Ai  = float(data.iloc[1,j])          
        Zi  = float(data.iloc[0,j])          
        rho = float(data.iloc[i,16]) #relative mass density

        sum_element = sum_element = wi/Ai * (Zi + k1*Zi**2.86 + k2*Zi**4.62)
        sum_row += sum_element

    HU_reduced = rho*(sum_row/sum_water)
    HU=(HU_reduced-1)*1000
    calc_HU.append(HU)

print("*** Calculated HU ***")
for i in range(0,62):
    HUx = calc_HU[i]
    tissue = data.iloc[i+2,0]
    #print (tissue[:13], ":\t", HUx)
    print(HUx)

##################################################
#### Calculating RSP for ICRU tissues
    
### Reading of relative electron densities
rho_list = []

for i in range(2,64):                   #Rows (Adipose# - Water)
    rho_tissue = float(data.iloc[i,16]) #Columns (16 = rho_e_rel)
    rho_list.append(rho_tissue)
    print(rho_tissue)
   
### Calculation of mean I-values for all tissues
#print("***I-values***")
e = math.e
I_list = []
for i in range (2,64):
    sum1 = 0
    sum2 = 0

    for j in range (1,13):              #Columns (H - I)
        lni = math.log(float(data.iloc[64,j]))
        wi  = (float(data.iloc[i,j]))/100          
        Ai  = float(data.iloc[1,j])          
        Zi  = float(data.iloc[0,j])
        sum1 += wi*(Zi/Ai)*lni
        sum2 += wi*(Zi/Ai)

    lni_mean = (sum1/sum2)
    I_list.append(lni_mean)
    #print(e**lni_mean)


######### Calculation of RSPs #########
MeV = 1e6
Iw = 78                     # eV
Ek = 100*MeV                # 100 MeV
me = 0.511*MeV           
mp = 938*MeV            
b  = (1-(1/((mp+Ek)/mp))**2)**(1/2) # Velocity of the 100 MeV proton [c]

S_ew = math.log(2*me*c**2*b**2)-math.log(1-b**2)-b**2-math.log(Iw) #Denomin

print("***RSP***")
RSP_list = []
for i in range (0,62):
    Ix = I_list[i]
    pe = rho_list[i]
    substitute = data.iloc[i+2,0]
    S_e = math.log(2*me*c**2*b**2)-math.log(1-b**2)-b**2-(Ix)

    RSP = pe*(S_e/S_ew)
    RSP_list.append(RSP)
    #print (substitute[:13],":\t",RSP)
    print (RSP)
