
### Calulate relative electron densities rho_e
### Calculate I-values for tissue subs


import pandas as pd
import numpy as np
from scipy.constants import c as c
import matplotlib.pyplot as plt
import math

data = pd.read_csv("Data/datablad_gammex_NY.csv")

### Calculation of relative electron densities
NA = 6.0221409*10**23   # Avrogados

wH = float(data.iloc[16,1])
AH = float(data.iloc[1,1])
ZH = float(data.iloc[0,1])
wO = float(data.iloc[16,4])
AO = float(data.iloc[1,4])
ZO = float(data.iloc[0,4])

n_ew = 1*NA*(wH*(ZH/AH) + wO*(ZO/AO))   # Electron density of water
rho_list = []

#print("***Electron densities***")
for i in range (2,18):                  # rows (CB2-30% - Breast)
    rho_m = float(data.iloc[i,11])      # mass densities
    sum = 0
##    rho_e = float(data.iloc[i,10])
##    rho_list.append(rho_e)
    for j in range (1,10):              # columns (H - Ca)
        wi  = float(data.iloc[i,j])          
        Ai  = float(data.iloc[1,j])          
        Zi  = float(data.iloc[0,j])
        sum += wi*(Zi/Ai)               # the sum in A.3 Goma
    
    n_e = rho_m*NA*sum
    rho_e = n_e/n_ew                    # Relative electron densities

    substitute = data.iloc[i,0]
    #print (substitute[:5],":\t",rho_e)
    rho_list.append(rho_e)              ### Save rho_e's to list

#print(rho_list)
    ###################


### Calculation of mean I-values for all subs
##e = math.e
#print("***I-values (log of I values)***")
I_list = []
e = math.e
for i in range (2,18):                  # rows (CB2-30% - Breast)
    sum1 = 0
    sum2 = 0
    
    for j in range (1,10):              # columns (H - Ca)
        lni = math.log(float(data.iloc[18,j]))
        wi  = float(data.iloc[i,j])          
        Ai  = float(data.iloc[1,j])          
        Zi  = float(data.iloc[0,j])
        sum1 += wi*(Zi/Ai)*lni
        sum2 += wi*(Zi/Ai)

    lni_mean = (sum1/sum2)
    I_list.append(lni_mean)             ### Save I-values to list
    #print(e**lni_mean)

####### Calculation of RSPs
MeV = 1e6
Iw = 78                             # eV
me = 0.511*MeV                      # electron mass
Ek = 100*MeV                        # 100 MeV
mp = 938*MeV                        # proton mass            
b  = (1-(1/((mp+Ek)/mp))**2)**(1/2) # Velocity of the 100 MeV proton [c]
#print (b)


S_ew = math.log(2*me*c**2*b**2)-math.log(1-b**2)-b**2-math.log(Iw) #Denomin

print("***RSP***")
for i in range (0,16):
    Ix = I_list[i] # Husk: allerede "log-et"
    pe = rho_list[i]
    substitute = data.iloc[i+2,0]
    S_e = math.log(2*me*c**2*b**2)-math.log(1-b**2)-b**2-(Ix)

    RSP = pe*(S_e/S_ew)
    #print (substitute[:5],":\t",RSP) # og lagre disse et sted. now we gottem
    print(round(RSP,3))
