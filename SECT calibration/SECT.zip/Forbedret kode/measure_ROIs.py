########################################
### Beginning of SECT stoichiometric ###
###          calibration             ###
########################################

import numpy as np
from scipy.optimize import minimize
import pandas as pd
import matplotlib.pyplot as plt
import pydicom
import glob
from math import *

########################################
###         3-slices ROI-mean        ###

def ROI(ar, circle, r):
    ROI    = np.zeros(np.shape(ar), dtype=np.bool_)
    x0, y0 = circle

    for y in range(floor(y0 - r), ceil(y0 + r) + 1):
        for x in range(floor(x0 - r), ceil(x0 + r) + 1):
            if (x - x0)**2 + (y - y0)**2 < r**2:
                ROI[y, x] = True
    return ROI

image = "Data/SE Abdomen  5.0  B40f - Calibration/*"


print("Measuring slices...\n")
for imageNo in range(6,9): #middle 3 slices (no. 7, 8, 9 in folder)
    ds     = pydicom.dcmread(glob.glob(image)[imageNo])
    img_ds = ds.pixel_array * ds.RescaleSlope + ds.RescaleIntercept
    radius = 15

    circles = {"CB2-30%":       (189, 105),
               "Lung 300":      (313, 105),
               "Inner bone":    (399, 194),
               "SW1":           (398, 317),
               "Cortical bone": (313, 405),
               "Liver":         (187, 405),
               "Brain":         (101, 317),
               "Lung 450":      (100, 190),
               "SW2":           (250, 169),
               "Adipose":       (310, 195),
               "SW3":           (335, 255),
               "B-200":         (310, 315),
               "Muscle":        (251, 340),
               "CB2-50%":       (190, 314),
               "Water":         (166, 255),
               "Breast":        (191, 194)
                }
    ROI_imageNo = []
    print("Mean HU-values in slice: ", ds.SliceLocation)
    for tissue in circles.keys():
        mean = np.mean(img_ds[ROI(img_ds, circles[tissue], radius)])
        ROI_imageNo.append(round(mean,2))
        print(round(mean,3))

     
    #print(ROI_imageNo, "\n")


    



